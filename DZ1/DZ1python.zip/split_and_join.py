s=input().split()
new_s="-".join(s)
print(new_s)