n=int(input())
if 1<=n<=20:
    for i in range(0,n):
        print(i**2)
else:
    print("Error!")