a=int(input())
b=int(input())
if b!=0:
    print(a//b)
    print(a/b)
else:
    print("Error!")